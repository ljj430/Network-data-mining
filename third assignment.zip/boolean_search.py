import os
class BinaryTree():
    def __init__(self):
        pass
    def create(self,item):
        return [item,[],[]]
    def insertLeft(self,tree,item):
        leftSubtree=tree.pop(1)
        if leftSubtree:
            tree.insert(1,[item,leftSubtree,[]])
        else:
            tree.insert(1,[item,[],[]])
        return tree
    def insertRight(self,tree,item):
        rightSubtree=tree.pop(2)
        if rightSubtree:
            tree.insert(2,[item,[],rightSubtree])
        else:
            tree.insert(2,[item,[],[]])
        return tree
    def getLeftChild(self,tree):
        return tree[1]
    def getRightChild(self,tree):
        return tree[2]

def save_data(word_search_path,index_search_path):
    file=open(word_search_path,'r')
    Word_Dic={}
    Str=file.readline().rstrip()
    while Str:
        data=Str.split('\t')
        Word_Dic[data[0]]=data[1:]
        Str=file.readline().rstrip()

    #进行索引保存数据
    file=open(index_search_path,'r')
    Index_Dic={}
    Str=file.readline().rstrip()

    while Str:
        data=Str.split('\t')
        Index_Dic[data[0]]=data[1]
        Str=file.readline().rstrip()
    return Word_Dic,Index_Dic


def serching_word(word,Index_Dic,Word_Dic):
    if word in Word_Dic:
        index=[]
        index=list(set(Word_Dic[word]))
    return index

def show_result(index,Index_Dic,Word_Dic):
    if index:
        print('共有%d条记录'%len(index))
        for i in index:
            print(i,'号文件')
            path=Index_Dic[i]
            print(path)
            file=open(path,'r')
            sentence=file.read()
            print(sentence)
            print('-  -'*40)
    else:
        print(i)
        print('nothing')

def save_query(sentence):
    words=sentence.split(' ')
    andtree=[]
    i=0
    while i<(len(words)):
        treeobject=BinaryTree()
        if words[i]=='and':
            tree=treeobject.create('and')
            treeobject.insertLeft(tree,words[i-1])
            treeobject.insertRight(tree,words[i+1])
            andtree.append(tree)
            andtree.pop(i-1)
            i+=2
        else:
            treeobject=BinaryTree()
            andtree.append(treeobject.create(words[i]))
            i+=1
    lastnode=andtree[0]
    ortree=[]
    for i in range(1,len(andtree)):
        currentnode=andtree[i]
        ortree=treeobject.create('or')
        ortree[1]=lastnode
        ortree[2]=currentnode
        lastnode=ortree
    return ortree

def boolean_search(tree,return_results):
    if tree[0]=='and':
        lstleftresults=boolean_search(tree[1],return_results)
        lstrightresults=boolean_search(tree[2],return_results)
        if lstleftresults!=None:
            for i in range(len(lstleftresults)):
                if lstleftresults[i] in lstrightresults:
                    return_results.append(lstleftresults.append(lstrightresults[i]))
    elif tree[0]=='or':
        lstleftresults=boolean_search(tree[1],return_results)
        lstrightresults=boolean_search(tree[2],return_results)
        if lstleftresults!=None:
            for i in range(len(lstleftresults)):
                if lstleftresults[i] not in return_results:
                    return_results.append(lstleftresults[i])
        if lstrightresults!=None:
            for i in range(len(lstrightresults)):
                if lstrightresults[i] not in return_results:
                    return_results.append(lstrightresults[i])
    else:

        return return_results.append(tree[0])
    return return_results
path_doucuments=".\documents"#打开ducuments文件所在位置"
path_DocIndex=".\index.txt"
path_WordIndex=".\invert.txt"
Word_search,Index_search=save_data(path_WordIndex,path_DocIndex)
sentence=input()
ortree=save_query(sentence)
index=[]
for i in boolean_search(ortree,[]):
    for j in serching_word(i,Index_search,Word_search):
        if j not in index:
            index.append(j)
show_result(index,Index_search,Word_search)



